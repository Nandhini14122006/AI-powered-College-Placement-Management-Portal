from flask import Flask, render_template, jsonify, request
import sqlite3
import google.generativeai as genai
from PyPDF2 import PdfReader
from dotenv import load_dotenv
import os

load_dotenv()

genai.configure(
    api_key=os.getenv("GEMINI_API_KEY")
)

#==============================
#AI RESUME ANALYZER
#==============================
def analyze_resume_with_ai(resume_text):

    model = genai.GenerativeModel("gemini-2.5-flash")

    prompt = f"""
    Analyze this resume and provide:

    1. Resume Score (/100)
    2. Strengths
    3. Weaknesses
    4. Missing Skills
    5. ATS Suggestions
    6. Recommended Certifications
    7. Suitable Job Roles
    8. Placement Readiness

    Resume:
    {resume_text}
    """

    response = model.generate_content(prompt)

    return response.text

app = Flask(__name__)

# ==============================
# DATABASE CONFIGURATION
# ==============================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_DIR = os.path.join(BASE_DIR, "database")
DATABASE_PATH = os.path.join(DATABASE_DIR, "smartprep.db")

os.makedirs(DATABASE_DIR, exist_ok=True)


def get_db_connection():
    connection = sqlite3.connect(DATABASE_PATH)
    connection.row_factory = sqlite3.Row
    return connection


# ==============================
# DATABASE INITIALIZATION
# ==============================

def init_db():
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS student_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            roll_number TEXT,
            phone TEXT,
            dob TEXT,
            branch TEXT,
            cgpa REAL,
            skills TEXT,
            linkedin TEXT,
            github TEXT,
            history_arrears TEXT,
            current_arrears INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS companies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            domain TEXT,
            description TEXT
        )
    """)
    cursor.execute("""
        INSERT OR IGNORE INTO companies (id, name, domain, description)
        VALUES
        (1, 'Zoho Corp', 'IT', 'Software and technology company'),
        (2, 'TCS', 'IT', 'Information technology services company'),
        (3, 'Cognizant', 'IT', 'Technology and consulting company')
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS placement_drives (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company_id INTEGER NOT NULL,
            min_cgpa REAL DEFAULT 0,
            package TEXT,
            allowed_branches TEXT,
            arrear_policy TEXT,
            drive_date TEXT,
            rounds TEXT,
            FOREIGN KEY (company_id) REFERENCES companies(id)
        )
    """)

    cursor.execute("""
        INSERT OR IGNORE INTO placement_drives
        (id, company_id, min_cgpa, package, allowed_branches, arrear_policy, drive_date, rounds)
        VALUES
        (1, 1, 7.0, '8.5 LPA', 'IT,CSE', 'No standing arrears', '2026-10-15', 'Aptitude,Technical,HR'),
        (2, 2, 6.0, '4.0 LPA', 'IT,CSE,Cyber Security', 'No restriction', '2026-10-20', 'Aptitude,Technical,HR'),
        (3, 3, 6.5, '4.5 LPA', 'IT,CSE,AI&DS', 'No history', '2026-10-25', 'Aptitude,Technical,HR')
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            drive_id INTEGER NOT NULL,
            status TEXT DEFAULT 'Applied',
            applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (drive_id) REFERENCES placement_drives(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS resumes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            filepath TEXT NOT NULL,
            uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            company TEXT NOT NULL,
            aptitude TEXT,
            technical TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            is_read INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    connection.commit()
    connection.close()


# ==============================
# HOME PAGE
# ==============================

@app.route("/")
def home():
    return render_template("index.html")


# ==============================
# DATABASE TEST
# ==============================

@app.route("/api/health")
def health():
    return jsonify({
        "status": "success",
        "message": "SmartPrep backend and database are working!"
    })


# ==============================
# REGISTER API
# ==============================

@app.route("/api/register", methods=["POST"])
def register():

    data = request.get_json()

    name = data.get("name", "").strip()
    email = data.get("email", "").strip()
    password = data.get("password", "").strip()
    role = data.get("role", "student").strip()

    if not name or not email or not password:
        return jsonify({
            "success": False,
            "message": "Name, email and password are required."
        }), 400

    connection = get_db_connection()
    cursor = connection.cursor()

    try:
        cursor.execute("""
            INSERT INTO users (name, email, password, role)
            VALUES (?, ?, ?, ?)
        """, (name, email, password, role))

        connection.commit()

        user_id = cursor.lastrowid

        return jsonify({
            "success": True,
            "message": "Registration successful!",
            "user_id": user_id
        })

    except sqlite3.IntegrityError:

        return jsonify({
            "success": False,
            "message": "This email is already registered."
        }), 409

    finally:
        connection.close()


# ==============================
# LOGIN API
# ==============================

@app.route("/api/login", methods=["POST"])
def login():

    data = request.get_json()

    email = data.get("email", "").strip()
    password = data.get("password", "").strip()

    if not email or not password:
        return jsonify({
            "success": False,
            "message": "Email and password are required."
        }), 400

    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        SELECT id, name, email, role
        FROM users
        WHERE email = ? AND password = ?
    """, (email, password))

    user = cursor.fetchone()

    connection.close()

    if user:
        return jsonify({
            "success": True,
            "message": "Login successful!",
            "user": {
                "id": user["id"],
                "name": user["name"],
                "email": user["email"],
                "role": user["role"]
            }
        })

    return jsonify({
        "success": False,
        "message": "Invalid email or password."
    }), 401


# ==============================
# GET USERS - TEST API
# ==============================

@app.route('/api/profile', methods=['POST'])
def save_profile():
    data = request.get_json()

    user_id = data.get('user_id')

    if not user_id:
        return jsonify({
            'message': 'User ID is required.'
        }), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO student_profiles (
                user_id,
                roll_number,
                phone,
                dob,
                branch,
                cgpa,
                skills,
                linkedin,
                github,
                history_arrears,
                current_arrears
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                roll_number = excluded.roll_number,
                phone = excluded.phone,
                dob = excluded.dob,
                branch = excluded.branch,
                cgpa = excluded.cgpa,
                skills = excluded.skills,
                linkedin = excluded.linkedin,
                github = excluded.github,
                history_arrears = excluded.history_arrears,
                current_arrears = excluded.current_arrears
        """, (
            user_id,
            data.get('roll_number'),
            data.get('phone'),
            data.get('dob'),
            data.get('branch'),
            data.get('cgpa'),
            data.get('skills'),
            data.get('linkedin'),
            data.get('github'),
            data.get('history_arrears'),
            data.get('current_arrears', 0)
        ))

        conn.commit()

        return jsonify({
            'message': 'Profile saved successfully.'
        }), 200

    except Exception as e:
        conn.rollback()
        return jsonify({
            'message': str(e)
        }), 500

    finally:
        conn.close()



@app.route('/api/drives', methods=['GET'])
def get_drives():

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            placement_drives.id,
            placement_drives.min_cgpa,
            placement_drives.package,
            placement_drives.allowed_branches,
            placement_drives.arrear_policy,
            placement_drives.drive_date,
            placement_drives.rounds,
            companies.name AS company_name
        FROM placement_drives
        LEFT JOIN companies
        ON placement_drives.company_id = companies.id
        ORDER BY placement_drives.id DESC
    """)

    drives = cursor.fetchall()

    conn.close()

    return jsonify([
        dict(drive)
        for drive in drives
    ])
@app.route("/api/users", methods=["GET"])
def get_users():

    connection = get_db_connection()

    users = connection.execute("""
        SELECT id, name, email, role, created_at
        FROM users
        ORDER BY id DESC
    """).fetchall()

    connection.close()

    return jsonify([
        dict(user) for user in users
    ])


# ==============================
# START APPLICATION
# ==============================
@app.route('/api/placement-drives', methods=['GET'])
def get_placement_drives():

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            placement_drives.id,
            companies.name AS company,
            companies.domain AS domain,
            placement_drives.min_cgpa,
            placement_drives.package,
            placement_drives.allowed_branches,
            placement_drives.arrear_policy,
            placement_drives.drive_date,
            placement_drives.rounds
        FROM placement_drives
        JOIN companies
            ON placement_drives.company_id = companies.id
        WHERE placement_drives.status = 'Open'
    """)

    drives = cursor.fetchall()
    conn.close()

    return jsonify([dict(drive) for drive in drives])
# ==============================
# UPDATE PLACEMENT DRIVE
# ==============================
@app.route('/api/placement-drives/<int:drive_id>', methods=['PUT'])
def update_placement_drive(drive_id):

    data = request.get_json()

    company_name = data.get('company', '').strip()
    domain = data.get('domain', '').strip()
    package = data.get('package', '').strip()
    min_cgpa = data.get('min_cgpa', 0)
    allowed_branches = data.get('allowed_branches', '').strip()
    arrear_policy = data.get('arrear_policy', '').strip()
    drive_date = data.get('drive_date', '').strip()
    rounds = data.get('rounds', '').strip()

    if not company_name:
        return jsonify({
            'success': False,
            'message': 'Company name is required.'
        }), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:

        # Find the company connected to this drive
        cursor.execute("""
            SELECT company_id
            FROM placement_drives
            WHERE id = ?
        """, (drive_id,))

        drive = cursor.fetchone()

        if not drive:
            return jsonify({
                'success': False,
                'message': 'Placement drive not found.'
            }), 404

        company_id = drive['company_id']

        # Update company information
        cursor.execute("""
            UPDATE companies
            SET name = ?, domain = ?
            WHERE id = ?
        """, (
            company_name,
            domain,
            company_id
        ))

        # Update placement drive information
        cursor.execute("""
            UPDATE placement_drives
            SET
                min_cgpa = ?,
                package = ?,
                allowed_branches = ?,
                arrear_policy = ?,
                drive_date = ?,
                rounds = ?
            WHERE id = ?
        """, (
            min_cgpa,
            package,
            allowed_branches,
            arrear_policy,
            drive_date,
            rounds,
            drive_id
        ))

        conn.commit()

        return jsonify({
            'success': True,
            'message': 'Placement drive updated successfully!'
        }), 200

    except Exception as e:

        conn.rollback()

        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

    finally:
        conn.close()
# ==============================
# CLOSE PLACEMENT DRIVE
# ==============================
@app.route('/api/placement-drives/<int:drive_id>/close', methods=['PUT'])
def close_placement_drive(drive_id):

    conn = get_db_connection()
    cursor = conn.cursor()

    try:

        cursor.execute("""
            UPDATE placement_drives
            SET status = 'Closed'
            WHERE id = ?
        """, (drive_id,))

        if cursor.rowcount == 0:
            return jsonify({
                'success': False,
                'message': 'Placement drive not found.'
            }), 404

        conn.commit()

        return jsonify({
            'success': True,
            'message': 'Placement drive closed successfully!'
        }), 200

    except Exception as e:

        conn.rollback()

        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

    finally:
        conn.close()

# ==============================
# CREATE PLACEMENT DRIVE
# ==============================
@app.route('/api/placement-drives', methods=['POST'])
def create_placement_drive():

    data = request.get_json()

    company_name = data.get('company')
    domain = data.get('domain', '')
    package = data.get('package', '')
    min_cgpa = data.get('min_cgpa', 0)
    allowed_branches = data.get('allowed_branches', '')
    arrear_policy = data.get('arrear_policy', '')
    drive_date = data.get('drive_date', '')
    rounds = data.get('rounds', '')

    if not company_name:
        return jsonify({
            'success': False,
            'message': 'Company name is required.'
        }), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:

        # Check if company already exists
        cursor.execute(
            "SELECT id FROM companies WHERE name = ?",
            (company_name,)
        )

        company = cursor.fetchone()

        if company:
            company_id = company['id']

        else:
            # Create company
            cursor.execute("""
                INSERT INTO companies (name, domain, description)
                VALUES (?, ?, ?)
            """, (
                company_name,
                domain,
                'Created from placement drive'
            ))

            company_id = cursor.lastrowid

        # Create placement drive
        cursor.execute("""
            INSERT INTO placement_drives (
                company_id,
                min_cgpa,
                package,
                allowed_branches,
                arrear_policy,
                drive_date,
                rounds
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            company_id,
            min_cgpa,
            package,
            allowed_branches,
            arrear_policy,
            drive_date,
            rounds
        ))

        drive_id = cursor.lastrowid

        conn.commit()

        return jsonify({
            'success': True,
            'message': 'Placement drive created successfully!',
            'drive_id': drive_id
        }), 201

    except Exception as e:

        conn.rollback()

        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

    finally:
        conn.close()
# ==============================
# APPLY FOR PLACEMENT DRIVE
# ==============================
@app.route('/api/apply', methods=['POST'])
def apply_for_drive():

    data = request.get_json()

    user_id = data.get('user_id')
    drive_id = data.get('drive_id')

    if not user_id or not drive_id:
        return jsonify({
            'success': False,
            'message': 'User ID and Drive ID are required.'
        }), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        # Check if the student already applied
        cursor.execute("""
            SELECT id
            FROM applications
            WHERE user_id = ? AND drive_id = ?
        """, (user_id, drive_id))

        existing_application = cursor.fetchone()

        if existing_application:
            return jsonify({
                'success': False,
                'message': 'You have already applied for this drive.'
            }), 409

        # Save application
        cursor.execute("""
            INSERT INTO applications (user_id, drive_id)
            VALUES (?, ?)
        """, (user_id, drive_id))

        conn.commit()

        return jsonify({
            'success': True,
            'message': 'Application submitted successfully!'
        }), 200

    except Exception as e:
        conn.rollback()

        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

    finally:
        conn.close()



# ==============================
# GET MY APPLICATIONS
# ==============================
@app.route('/api/my-applications/<int:user_id>', methods=['GET'])
def get_my_applications(user_id):

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT
            applications.id,
            companies.name AS company,
            placement_drives.drive_date,
            placement_drives.package,
            applications.status,
            applications.applied_at
        FROM applications
        JOIN placement_drives
            ON applications.drive_id = placement_drives.id
        JOIN companies
            ON placement_drives.company_id = companies.id
        WHERE applications.user_id = ?
        ORDER BY applications.applied_at DESC
    """, (user_id,))

    applications = cursor.fetchall()
    conn.close()

    return jsonify([dict(application) for application in applications])


# ==============================
# VIEW APPLICATIONS FOR A DRIVE
# ==============================
@app.route('/api/applications/drive/<int:drive_id>', methods=['GET'])
def get_drive_applications(drive_id):

    conn = get_db_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT
                applications.id AS application_id,
                applications.status,
                applications.applied_at,

                users.id AS user_id,
                users.name,
                users.email,

                student_profiles.roll_number,
                student_profiles.branch,
                student_profiles.cgpa,
                student_profiles.skills

            FROM applications

            JOIN users
                ON applications.user_id = users.id

            LEFT JOIN student_profiles
                ON applications.user_id = student_profiles.user_id

            WHERE applications.drive_id = ?

            ORDER BY applications.applied_at DESC
        """, (drive_id,))

        applications = cursor.fetchall()

        return jsonify([
            dict(application)
            for application in applications
        ]), 200

    except Exception as e:

        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

    finally:
        conn.close()

# ==============================
# UPDATE APPLICATION STATUS
# ==============================
@app.route('/api/update-application-status', methods=['POST'])
def update_application_status():

    data = request.get_json()

    application_id = data.get('application_id')
    status = data.get('status')

    if not application_id or not status:
        return jsonify({
            'success': False,
            'message': 'Application ID and status are required.'
        }), 400

    conn = get_db_connection()
    cursor = conn.cursor()

    try:

        cursor.execute("""
            SELECT user_id
            FROM applications
            WHERE id = ?
        """, (application_id,))

        application = cursor.fetchone()

        if not application:
            return jsonify({
                'success': False,
                'message': 'Application not found.'
        }), 404

        student_user_id = application['user_id']

        cursor.execute("""
            UPDATE applications
            SET status = ?
            WHERE id = ?
        """, (status, application_id))

        if cursor.rowcount == 0:
            return jsonify({
                'success': False,
                'message': 'Application not found.'
            }), 404

        conn.commit()

        return jsonify({
            'success': True,
            'message': 'Application status updated successfully!'
        }), 200

    except Exception as e:

        conn.rollback()

        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

    finally:
        conn.close()

#===================================
#AI analyzer
#===================================
@app.route("/ai/resume-analyzer", methods=["POST"])
def ai_resume_analyzer():

    uploaded_file = request.files.get("resume")

    if not uploaded_file:
        return jsonify({"error": "No file uploaded"})

    upload_folder = "uploads"
    os.makedirs(upload_folder, exist_ok=True)

    file_path = os.path.join(
        upload_folder,
        uploaded_file.filename
    )

    uploaded_file.save(file_path)

    resume_text = extract_pdf_text(file_path)

    result = analyze_resume_with_ai(resume_text)

    return jsonify({
        "analysis": result
    })


#======================================
#extract pdf
#=====================================
def extract_pdf_text(pdf_path):
    text = ""

    reader = PdfReader(pdf_path)

    for page in reader.pages:
        page_text = page.extract_text()

        if page_text:
            text += page_text + "\n"

    return text


if __name__ == "__main__":
    init_db()
    app.run(debug=True)